<?php
declare(strict_types=1);

// @deprecated 4.1.0 Add backwards compatible alias.
class_alias('Cake\Database\Driver\SqlDialectTrait', 'Cake\Database\SqlDialectTrait');
